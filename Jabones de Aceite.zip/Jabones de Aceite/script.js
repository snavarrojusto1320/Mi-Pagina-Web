function cambiarFondo() {
  document.body.style.backgroundColor = '#e0ffe0';
}
